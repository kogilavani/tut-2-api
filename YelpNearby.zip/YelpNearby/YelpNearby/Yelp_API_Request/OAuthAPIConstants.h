//
//  OAuthAPIConstants.h
//  YelpNearby
//
//  Created by Behera, Subhransu on 8/14/13.
//  Copyright (c) 2013 Behera, Subhransu. All rights reserved.
//

#ifndef YelpNearby_OAuthAPIConstants_h
#define YelpNearby_OAuthAPIConstants_h

#define OAUTH_CONSUMER_KEY @"AMyFeUakHL0XlVld6g1iPA"
#define OAUTH_CONSUMER_SECRET @"c4-IsXWYFsOkwBPINFyKamEGO30"
#define OAUTH_TOKEN @"3mhGa8Y95FoLmySdC5RjAiDKc87mAka5"
#define OAUTH_TOKEN_SECRET @"_TLY9AJt63UzC8B3S05fi0cU3LE"
#define YELP_SEARCH_URL @"http://api.yelp.com/v2/search"



#endif
